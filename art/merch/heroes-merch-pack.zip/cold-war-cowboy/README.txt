cold-war-cowboy from Midlife Survivors - merch source files
Native size 56x60 px, front-facing standing pose. 8x = 448x480, 16x = 896x960, nearest-neighbor.
Files: -front-56x60 (native, transparent), -front-8x, -front-16x, -front-16x-white-bg (preview), -silhouette-16x (one-color / engraving)
Opaque pixels: 1133, colors: 17
Top colors:
  #171C35  (418 px)
  #874C3B  (103 px)
  #E5A995  (101 px)
  #303750  (94 px)
  #526078  (73 px)
Thin parts to watch when printing: arms, mug handle, glasses. Keep 1 px >= 1 mm or thicken.
