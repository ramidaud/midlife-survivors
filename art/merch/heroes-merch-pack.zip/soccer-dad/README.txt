soccer-dad from Midlife Survivors - merch source files
Native size 56x60 px, front-facing standing pose. 8x = 448x480, 16x = 896x960, nearest-neighbor.
Files: -front-56x60 (native, transparent), -front-8x, -front-16x, -front-16x-white-bg (preview), -silhouette-16x (one-color / engraving)
Opaque pixels: 1165, colors: 15
Top colors:
  #171C35  (327 px)
  #3E7775  (163 px)
  #EF9347  (139 px)
  #303750  (110 px)
  #526078  (83 px)
Thin parts to watch when printing: arms, mug handle, glasses. Keep 1 px >= 1 mm or thicken.
