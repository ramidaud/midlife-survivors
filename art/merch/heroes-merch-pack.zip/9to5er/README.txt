9to5er from Midlife Survivors - merch source files
Native size 56x60 px, front-facing standing pose. 8x = 448x480, 16x = 896x960, nearest-neighbor.
Files: -front-56x60 (native, transparent), -front-8x, -front-16x, -front-16x-white-bg (preview), -silhouette-16x (one-color / engraving)
Opaque pixels: 1124, colors: 16
Top colors:
  #171C35  (337 px)
  #874C3B  (140 px)
  #FFF0CF  (126 px)
  #70402F  (113 px)
  #EF9347  (105 px)
Thin parts to watch when printing: arms, mug handle, glasses. Keep 1 px >= 1 mm or thicken.
