grad-student from Midlife Survivors - merch source files
Native size 56x60 px, front-facing standing pose. 8x = 448x480, 16x = 896x960, nearest-neighbor.
Files: -front-56x60 (native, transparent), -front-8x, -front-16x, -front-16x-white-bg (preview), -silhouette-16x (one-color / engraving)
Opaque pixels: 972, colors: 14
Top colors:
  #171C35  (298 px)
  #70402F  (161 px)
  #303750  (115 px)
  #EF9347  (102 px)
  #A88B70  (53 px)
Thin parts to watch when printing: arms, mug handle, glasses. Keep 1 px >= 1 mm or thicken.
