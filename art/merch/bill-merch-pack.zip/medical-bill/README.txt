Medical Bill from Midlife Survivors - merch source files
The pink invoice that shows up when the Hustle meter fills (Kevin's idea). Native 48x48 px.
8x = 384px, 16x = 768px, nearest-neighbor. Files: -frame0/-frame2 (two walk poses), -silhouette (one-color/engraving), -white-bg (preview).
Opaque pixels 1038, colors 10. Key colors:
  #F2D7A1  (258 px)
  #171C35  (228 px)
  #F1B5BF  (151 px)
  #FFF0CF  (114 px)
  #BFA8CF  (85 px)
Thin parts: arms and feet are 3-4 px wide; keep 1 px >= 1 mm or thicken.
