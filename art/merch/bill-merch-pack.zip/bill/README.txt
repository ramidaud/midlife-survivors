Medical Bill ("Bill") from Midlife Survivors - merch source files
Rami Daud, Nov 2026

Native sprite size: 48x48 pixels. Everything else is a whole-number enlargement
(8x = 384px, 16x = 768px) using nearest-neighbor, so pixels stay crisp.

bill-frame0-48px.png        native size, transparent background (idle / standing pose)
bill-frame0-384px.png       8x, transparent
bill-frame0-768px.png       16x, transparent
bill-frame0-768px-white-bg.png  16x on white, for quick previews
bill-frame2-*.png           same thing, alternate walk pose
bill-silhouette-768px.png   solid black outline shape, for laser engraving or single-color prints

Palette (13 colors total). The four that matter if you reduce to single filament or two-tone:
  cream paper   #FFF0CF
  navy outline  #171C35
  red stripe    #C45C4B
  tan shading   #F2D7A1

Thin bits to watch for printing: the two arms are 3-4 pixels wide, the feet are small.
Scale so one pixel is at least 1 mm, or thicken those in the model.
